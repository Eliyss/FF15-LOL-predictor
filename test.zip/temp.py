import requests
import pandas as pd
import requests_cache
import numpy as np

requests_cache.install_cache('amazon2', backend='sqlite', expire_after=7200)

# r = requests.get('https://s3-us-west-1.amazonaws.com/riot-developer-portal/seed-data/matches2.json')
# 
# print(r.from_cache)
# 
# page = r.json()

champ0, champ1, champ2, champ3, champ4, champ5, champ6, champ7, champ8, champ9 = [], [], [], [], [], [], [], [], [], []
win = []

for j in range(1,11):
    r = requests.get('https://s3-us-west-1.amazonaws.com/riot-developer-portal/seed-data/matches'+str(j)+'.json')
    print(str(r.from_cache) + ' ' + str(j))
    page = r.json()
    for i in range(100):
        champ0.append(page['matches'][i]['participants'][0]['championId'])
        champ1.append(page['matches'][i]['participants'][1]['championId'])
        champ2.append(page['matches'][i]['participants'][2]['championId'])
        champ3.append(page['matches'][i]['participants'][3]['championId'])
        champ4.append(page['matches'][i]['participants'][4]['championId'])
        champ0.append(page['matches'][i]['participants'][5]['championId'])
        champ1.append(page['matches'][i]['participants'][6]['championId'])
        champ2.append(page['matches'][i]['participants'][7]['championId'])
        champ3.append(page['matches'][i]['participants'][8]['championId'])
        champ4.append(page['matches'][i]['participants'][9]['championId'])
        win.append(page['matches'][i]['teams'][0]['win'] == 'Win')
        win.append(page['matches'][i]['teams'][1]['win'] == 'Win')


d = {'champ0' : pd.Series(champ0),
     'champ1' : pd.Series(champ1),
     'champ2' : pd.Series(champ2),
     'champ3' : pd.Series(champ3),
     'champ4' : pd.Series(champ4),
    # 'champ5' : pd.Series(champ5),
    # 'champ6' : pd.Series(champ6),
    # 'champ7' : pd.Series(champ7),
    # 'champ8' : pd.Series(champ8),
    # 'champ9' : pd.Series(champ9),
     'win' : pd.Series(win)}
    
df = pd.DataFrame(d)\

print(df)

df.to_csv('foo2.csv')
