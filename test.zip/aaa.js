var a = []+[[][]]
print(a)
