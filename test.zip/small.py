import requests
import pandas as pd
import requests_cache
import numpy as np
import json

requests_cache.install_cache('amazon3', backend='sqlite', expire_after=7200)

top, jg, mid, adc, supp = [], [], [], [], []

win = []

print("test")

for j in range(1,2):

    with open('matches1.json') as f:
        page = json.load(f)
    # r = requests.get('https://s3-us-west-1.amazonaws.com/riot-developer-portal/seed-data/matches1.json')
    # r = open('matches1.json')
    # page = json.load(r)
    # print(r)
    print('mad it')
    # page = r.json()
    print('still foso')
    for i in range(100):
        for k in range (10):
            if (page['matches'][i]['participants'][0]['timeline']['role'] == 'TOP'):
                top.append(page['matches'][i]['participants'][k]['championId'])
            elif (page['matches'][i]['participants'][0]['timeline']['lane'] == 'JUNGLE'):
                jg.append(page['matches'][i]['participants'][k]['championId'])
            elif (page['matches'][i]['participants'][0]['timeline']['role'] == 'MIDDLE'):
                mid.append(page['matches'][i]['participants'][k]['championId'])
            elif (page['matches'][i]['participants'][i]['timeline']['role'] == 'DUO_CARRY'):
                adc.append(page['matches'][i]['participants'][k]['championId'])
            elif (page['matches'][i]['participants'][0]['timeline']['role'] == 'DUO_SUPPORT'):
                supp.append(page['matches'][i]['participants'][k]['championId'])

        win.append(page['matches'][i]['teams'][0]['win'] == 'Win')
        win.append(page['matches'][i]['teams'][1]['win'] == 'Win')


d = {'top' : pd.Series(top),
     'jg' : pd.Series(jg),
     'mid' : pd.Series(mid),
     'adc' : pd.Series(adc),
     'supp' : pd.Series(supp),
     'win' : pd.Series(win)}
    
df = pd.DataFrame(d)\

print(df)

df.to_csv('roles.csv')
